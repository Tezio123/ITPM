/*IT17088374*/
package pac_model;

public class ModelInheritance {

	int lineNumber,direct,indirect;
	String className;
	
	public int getLineNumber() {
		return lineNumber;
	}
	public void setLineNumber(int lineNumber) {
		this.lineNumber = lineNumber;
	}
	public int getDirect() {
		return direct;
	}
	public void setDirect(int direct) {
		this.direct = direct;
	}
	public int getIndirect() {
		return indirect;
	}
	public void setIndirect(int indirect) {
		this.indirect = indirect;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}

}
