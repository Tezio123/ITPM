/*IT16166066*/
package pac_model;

public class ModelControls {

	int lineNumber,line_weight,no_of_control,cspps;
	String line;
	public int getLineNumber() {
		return lineNumber;
	}
	public void setLineNumber(int lineNumber) {
		this.lineNumber = lineNumber;
	}
	public int getLine_weight() {
		return line_weight;
	}
	public void setLine_weight(int line_weight) {
		this.line_weight = line_weight;
	}
	public int getNo_of_control() {
		return no_of_control;
	}
	public void setNo_of_control(int no_of_control) {
		this.no_of_control = no_of_control;
	}
	public int getCspps() {
		return cspps;
	}
	public void setCspps(int cspps) {
		this.cspps = cspps;
	}
	public String getLine() {
		return line;
	}
	public void setLine(String line) {
		this.line = line;
	}
	
}
